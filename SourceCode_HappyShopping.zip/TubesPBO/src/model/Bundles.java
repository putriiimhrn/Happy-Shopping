package model;


public class Bundles {
    private int bundle_id;
    private String bundle_name;
    private String description;
    private double discounted_price;
    private int stock;

    public int getBundle_id() {
        return bundle_id;
    }

    public void setBundle_id(int bundle_id) {
        this.bundle_id = bundle_id;
    }

    public String getBundle_name() {
        return bundle_name;
    }

    public void setBundle_name(String bundle_name) {
        this.bundle_name = bundle_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getDiscounted_price() {
        return discounted_price;
    }

    public void setDiscounted_price(double discounted_price) {
        this.discounted_price = discounted_price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
    
}