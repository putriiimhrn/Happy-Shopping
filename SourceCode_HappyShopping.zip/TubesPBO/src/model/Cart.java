package model;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public abstract class Cart {
    private int id;
    private String product_name;
    private String brand;
    private double price;
    private int quantity;
    private double total;
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    abstract public void displayReceipt(JFrame f, JCheckBox[] nameLabels, JLabel[] brandLabels,
        JLabel[] hargaLabels, JLabel[] quantityLabels, JLabel[] totalLabels);
    
    abstract public void checkout(JCheckBox[] checkboxes);
}
