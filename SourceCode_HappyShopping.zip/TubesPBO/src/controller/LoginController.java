package controller;

import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import model.customer;
import view.MainMenuView;

public class LoginController {
    private Database db = new Database();
    private customer c = customer.getInstance();
    
    public void login(JFrame f, String username, String password){
        String sql = "SELECT * FROM customer WHERE username='"+username+"' AND password='"+password+"';";
        try{
            
     
            ResultSet rs = db.view(sql);
            
            if (rs.next()) {
                // Pengguna dengan kombinasi username dan password yang valid ditemukan
                JOptionPane.showMessageDialog(null, "Login successful");
                c.setCustomer_id(rs.getString("customer_id"));
                f.setVisible(false);
                MainMenuView obj = new MainMenuView();
                obj.setVisible(true);
            } else {
                // Tidak ada pengguna yang cocok dengan kombinasi customer_id dan password
                JOptionPane.showMessageDialog(null, "Login unsuccessful. Incorrect username or password.");
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void disable(JPasswordField txtpassword, JLabel disable, JLabel show){
        txtpassword.setEchoChar((char)0);
        disable.setVisible(false);
        disable.setEnabled(false);
        show.setEnabled(true);
        show.setEnabled(true);
    }
    public void Show(JPasswordField txtpassword, JLabel disable, JLabel show){
        txtpassword.setEchoChar((char)8226);
        disable.setVisible(true);
        disable.setEnabled(true);
        show.setEnabled(false);
        show.setEnabled(false);;
    }
        
    public void form(JFrame fr){
        for (double i = 0.0; i <=1.0; i = i+0.1){
            String val = i+ "";
            float f = Float.valueOf(val);
            fr.setOpacity(f);
            try{
                Thread.sleep(50);
            }catch(Exception e){
                
            }
        }
    }
}
