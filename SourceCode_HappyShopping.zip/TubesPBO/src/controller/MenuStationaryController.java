package controller;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import model.Products;
import model.customer;

public class MenuStationaryController{
    private Products products = new Products();
    private Database db = new Database();
    private customer c = customer.getInstance();
    public void showMenuStationary(JLabel[] nameLabels, JLabel[] brandLabels, JLabel[] hargaLabels, JLabel[] stockLabels){
        String psql = "SELECT product_name, brand, price, stock FROM products WHERE category = 'stationery' ORDER BY id;";

        try{
       
            ResultSet rs = db.view(psql);
            int i = 0;
            
            while (rs.next() && i < 15)
            {
                
                products.setProduct_name(rs.getString("product_name"));
                products.setBrand(rs.getString("brand"));
                products.setPrice(rs.getDouble("price"));
                products.setStock(rs.getInt("stock"));
            
                nameLabels[i].setText(products.getProduct_name());
                brandLabels[i].setText(products.getBrand());
                hargaLabels[i].setText("$ " + Double.toString(products.getPrice()));
                stockLabels[i].setText(Integer.toString(products.getStock()) + " pcs");

                i++;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void addToCart(int index, JLabel[] nameLabels, JLabel[] brandLabels, JLabel[] hargaLabels) {        
        products.setProduct_name( nameLabels[index].getText());
        products.setBrand(brandLabels[index].getText());
        products.setPrice(Double.parseDouble(hargaLabels[index].getText().replace("$ ", "")));

        addToCartDatabase(products.getProduct_name(), products.getBrand(), products.getPrice());
        JOptionPane.showMessageDialog(null, products.getProduct_name() + " added to cart.");

        
    }
    public void addToCartDatabase(String productName, String brand, double price) {
        String insertSql = "INSERT INTO Cart (product_name, brand, price, quantity, total, customer_id) "
            + "VALUES ('"+productName+"', '"+brand+"', '"+price+"', 1, '"+price+"', '"+c.getCustomer_id()+"')";

        String updateSql = "UPDATE Cart SET quantity = quantity + 1, total = quantity * price "
            + "WHERE product_name =  '"+productName+"';";

        try {
            
            // Cek apakah produk sudah ada di dalam tabel
            String sql = "SELECT COUNT(*) FROM Cart WHERE product_name = '"+productName+"';";
         
            ResultSet rs = db.view(sql);
            rs.next();
            int count = rs.getInt(1);

            if (count > 0) {
                // Jika produk sudah ada, update quantity
                db.update(updateSql);
            } else {
                // Jika produk belum ada, insert data baru
                db.update(insertSql);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
