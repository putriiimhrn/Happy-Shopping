package controller;

import view.CartView;
import view.MainMenuView;
import java.awt.BorderLayout;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import model.Cart;
import model.customer;


public class CartController extends Cart {
    private Database db = new Database();
    private customer c = customer.getInstance();
    public void fillCart(JCheckBox[] nameLabels, JLabel[] brandLabels,
        JLabel[] hargaLabels, JLabel[] quantityLabels, JLabel[] totalLabels){
        String psql = "SELECT product_name, brand, price, quantity, total FROM cart WHERE customer_id='"+c.getCustomer_id()+"' ORDER BY id;";
        ResultSet rs = db.view(psql);
        
        try {
            if (!rs.first()) {
                JOptionPane.showMessageDialog(null, "Cart Empty");
                for (int j = 0; j < 20; j++) {
                    nameLabels[j].setVisible(false);
                    brandLabels[j].setVisible(false);
                    hargaLabels[j].setVisible(false);
                    quantityLabels[j].setVisible(false);
                    totalLabels[j].setVisible(false);
                }
            }else{
                int i = 0;
                do{
                    super.setProduct_name(rs.getString("product_name"));
                    super.setBrand(rs.getString("brand"));
                    super.setPrice(rs.getDouble("price"));
                    super.setQuantity(rs.getInt("quantity"));
                    super.setTotal(rs.getDouble("total"));
                    
                    nameLabels[i].setText(super.getProduct_name());
                    if (!super.getBrand().equals("null")) {
                        brandLabels[i].setText("by " + super.getBrand() );
                    } else {
                        brandLabels[i].setText("");
                    }
                    hargaLabels[i].setText("$ " + Double.toString(super.getPrice()) );
                    quantityLabels[i].setText(Integer.toString(super.getQuantity()) + " pcs");
                    totalLabels[i].setText("$ " + Double.toString(super.getTotal()));
                    i++;
                }while (rs.next() && i < 20);
                
                for (int j = i; j < 20; j++) {
                    nameLabels[j].setVisible(false);
                    brandLabels[j].setVisible(false);
                    hargaLabels[j].setVisible(false);
                    quantityLabels[j].setVisible(false);
                    totalLabels[j].setVisible(false);
                }
            }
        } catch (SQLException ex) {         
            Logger.getLogger(CartController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public int getQuantityFromCart(String productName) throws SQLException {
        String query = "SELECT quantity FROM cart WHERE product_name = '"+productName+"' and customer_id='"+c.getCustomer_id()+"';";
        ResultSet rs = db.view(query);
        if (rs.next()) {
            return rs.getInt("quantity");
        }
        return 0;
    }

    public void removeFromCart(String productName) throws SQLException {
        String deleteQuery = "DELETE FROM cart WHERE product_name = '"+productName+"' and customer_id='"+c.getCustomer_id()+"';";
        db.update(deleteQuery);
    }

    public void updateStockInProducts(String productName, int quantity) throws SQLException {
        int currentStock = getStockFromProducts(productName);

        if (currentStock >= quantity) {
            int newStock = currentStock - quantity;
            String updateQuery = "UPDATE products SET stock = '"+newStock+"' WHERE product_name = '"+productName+"';";
            db.update(updateQuery);
        } else {
            JOptionPane.showMessageDialog(null, "Insufficient stock of " + productName +" products");
        }
    }

    public int getStockFromProducts(String productName) throws SQLException {
        String query = "SELECT stock FROM products WHERE product_name = '"+productName+"';";
        ResultSet rs = db.view(query);
        if (rs.next()) {
            return rs.getInt("stock");
        }
        return 0;
    }
    
    public double getPriceFromProducts(String productName) throws SQLException {
        String query = "SELECT price FROM products WHERE product_name = '"+productName+"';";
        ResultSet rs = db.view(query);
        if (rs.next()) {
            return rs.getInt("price");
        }
        return 0.0;
    }

    public boolean isBundle(String productName) throws SQLException {
        String query = "SELECT COUNT(*) AS count FROM bundles WHERE bundle_name = '"+productName+"';";
        ResultSet rs = db.view(query);
        if (rs.next()) {
            return rs.getInt("count") > 0;
        }
        return false;
    }

    public void checkoutBundle(String bundleName, int quantity) throws SQLException {
        // Update stock in the bundles table
        String updateBundleStockQuery = "UPDATE bundles SET stock = stock - '"+quantity+"' WHERE bundle_name = '"+bundleName+"';";
        db.update(updateBundleStockQuery);
    
        // Get the products in the bundle
        String getBundleProductsQuery = "SELECT product_id, quantity "
                                      + "FROM bundle_products WHERE bundle_id = "
                                      + "(SELECT bundle_id FROM bundles WHERE bundle_name = '"+bundleName+"')";
        ResultSet rs = db.view(getBundleProductsQuery);
        while (rs.next()) {
            String productName = getProductName(rs.getInt("product_id"));
            int quantityInBundle = rs.getInt("quantity");

            // Remove the product from the super
            removeFromCart(productName);

            // Update stock in the products table for products in the bundle
            updateStockInProducts(productName, quantity * quantityInBundle);
        }
    }

    public void updateStockInBundles(String bundleName, int quantity) throws SQLException {
        String updateBundleStockQuery = "UPDATE bundles SET stock = stock - '"+quantity+"' WHERE bundle_name = '"+bundleName+"';";
        db.update(updateBundleStockQuery);

        // Update stock in the products table for products in the bundle
        String updateProductsStockQuery = "UPDATE products p " +
                                         "INNER JOIN bundle_products bp ON p.id = bp.product_id " +
                                         "SET p.stock = p.stock - (bp.quantity * '"+quantity+"') " +
                                         "WHERE bp.bundle_id = (SELECT bundle_id FROM bundles WHERE bundle_name = '"+bundleName+"');";
        db.update(updateProductsStockQuery);
    }
    
    public String getProductName(int productId) throws SQLException {
        String query = "SELECT product_name FROM products WHERE id = '"+productId+"';";
        ResultSet rs = db.view(query);
        if (rs.next()) {
            return rs.getString("product_name");
        }
        
        return null;
    }
    public void delete(JCheckBox[] checkboxes ){
        // Loop melalui semua checkbox
        for (int i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].isSelected()) {
                // Jika checkbox dicentang, ambil nama produk
                String productName = checkboxes[i].getText();

                try {
                    // Hapus data dari tabel super berdasarkan nama produk
                    removeFromCart(productName);
                } catch (SQLException ex) {
                    Logger.getLogger(CartController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Data of the product has been successfully deleted"); 
    }
    public void checkout(JCheckBox[] checkboxes){
        // Loop through the super items
        try {
            for (int i = 0; i < checkboxes.length; i++) {
                if (checkboxes[i].isSelected()) {
                    // Product is selected for checkout
                    String productName = checkboxes[i].getText();
                    int quantityIndividual;
                        quantityIndividual = getQuantityFromCart(productName);
                    // Check if the product is a bundle
                    if (isBundle(productName)) {
                        // Handle bundle checkout
                        removeFromCart(productName);
                        checkoutBundle(productName, quantityIndividual);
                    } else {
                        // Handle individual product checkout
                        removeFromCart(productName);
                        updateStockInProducts(productName, quantityIndividual);
                    }
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(CartController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void displayReceipt(JFrame f, JCheckBox[] nameLabels, JLabel[] brandLabels,
        JLabel[] hargaLabels, JLabel[] quantityLabels, JLabel[] totalLabels) {
        JFrame receiptFrame = new JFrame("Receipt");
        JTextArea receiptArea = new JTextArea();
        receiptArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        receiptArea.setEditable(false);
        
        JScrollPane scrollPane = new JScrollPane(receiptArea);
        receiptFrame.add(scrollPane);

        double totalBelanja = 0.0;

        
        receiptArea.append("                   HAPPY SHOPPING                      \n");
        receiptArea.append("\n-----------------------RECEIPT-----------------------\n");
        receiptArea.append(String.format("%-30s %7s %5s %7s\n", "Product", "Price", " Qty", "Total"));
        receiptArea.append("-----------------------------------------------------\n\n");

        for (int i = 0; i < nameLabels.length; i++) {
            if (nameLabels[i].isSelected()) {
                super.setProduct_name(nameLabels[i].getText());
                super.setBrand(brandLabels[i].getText());
                super.setPrice(Double.parseDouble(hargaLabels[i].getText().replace("$ ", "")));
                super.setQuantity(Integer.parseInt(quantityLabels[i].getText().replace(" pcs", "")));
                super.setTotal(Double.parseDouble(totalLabels[i].getText().replace("$ ", "")));

                receiptArea.append(String.format("%-30s %7.2f %5d %7.2f\n", super.getProduct_name(), super.getPrice(), super.getQuantity(), super.getTotal()));
                receiptArea.append(String.format("%-30s\n\n", super.getBrand()));

                totalBelanja += super.getTotal();
            }
        }

        receiptArea.append("-----------------------------------------------------\n");

        DecimalFormat decimalFormat = new DecimalFormat("#.##");
        String formattedTotal = decimalFormat.format(totalBelanja);

        receiptArea.append(String.format("%-36s %15s\n\n", "Total :", "$" + formattedTotal));
        // Create OK button
        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> {
            receiptFrame.dispose();
            f.setVisible(false);
            new MainMenuView().setVisible(true);
            
        });

        receiptFrame.add(okButton, BorderLayout.SOUTH); 
        receiptFrame.pack();
        receiptFrame.setLocationRelativeTo(null);
        receiptFrame.setVisible(true);
    }
    public void refreshCartView(JFrame f) {
        new CartView().setVisible(true);
        f.dispose(); 
    }
}
