package controller;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import model.Bundles;

public class MenuDiscountController extends MenuStationaryController{
        
    private Database db = new Database();
    private Bundles bundles = new Bundles();
    
    public void showMenuDiscount(JLabel[] nameLabels, JLabel[] hargaLabels, JLabel[] stockLabels){
        String psql = "SELECT bundle_name, discounted_price, stock FROM bundles ORDER BY bundle_id;";
        try{
            ResultSet rs = db.view(psql);
            int i = 0;

            while (rs.next() && i < 8)
            {             
                bundles.setBundle_name(rs.getString("bundle_name"));
                bundles.setDiscounted_price(rs.getDouble("discounted_price"));
                bundles.setStock(rs.getInt("stock"));

                nameLabels[i].setText(bundles.getBundle_name());
                hargaLabels[i].setText("$ " + Double.toString(bundles.getDiscounted_price()));
                stockLabels[i].setText(Integer.toString(bundles.getStock()) + " pcs");

                i++;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void showBundleProducts(int bundleId) {
        try {
            String bundleSql = "SELECT bundle_name, description, discounted_price FROM bundles WHERE bundle_id = '"+bundleId+"';";
            String productSql = "SELECT p.product_name, p.price, bp.quantity FROM bundle_products bp "
                    + "JOIN products p ON bp.product_id = p.id "
                    + "WHERE bp.bundle_id = '"+bundleId+"';";

            ResultSet bundleRs = db.view(bundleSql);

            // Membaca informasi bundle
            bundles.setBundle_name("");
            bundles.setDescription("");
            double discountedPrice = 0.0;

            if (bundleRs.next()) {
                bundles.setBundle_name(bundleRs.getString("bundle_name"));
                bundles.setDescription(bundleRs.getString("description"));
                bundles.setDiscounted_price(bundleRs.getDouble("discounted_price"));
            }

            // Membaca informasi produk
            ResultSet productRs = db.view(productSql);

            JFrame frame = new JFrame("Bundle Products Detail");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            frame.setSize(524, 450);
            frame.setLocationRelativeTo(null);

            // Panel utama
            JPanel mainPanel = new JPanel(null); // Layout null untuk penempatan manual
            mainPanel.setBackground(Color.WHITE);

            // Panel informasi bundle
            JPanel bundlePanel = new JPanel(new GridLayout(3, 1));
            bundlePanel.setBounds(4, 10, 500, 100); // Koordinat dan ukuran panel
            bundlePanel.setBackground(new Color(24,44,97));

            JLabel bundleNameLabel = new JLabel       (" Bundle         :  " + bundles.getBundle_name());
            JLabel bundleDescriptionLabel = new JLabel(" Description  : " + bundles.getDescription());
            JLabel discountedPriceLabel = new JLabel  (" Discounted Price  : $ " + bundles.getDiscounted_price());

            bundleNameLabel.setForeground(Color.WHITE);
            bundleDescriptionLabel.setForeground(Color.WHITE);
            discountedPriceLabel.setForeground(Color.WHITE);

            bundlePanel.add(bundleNameLabel);
            bundlePanel.add(bundleDescriptionLabel);
            bundlePanel.add(discountedPriceLabel);

            mainPanel.add(bundlePanel);

            // Panel informasi produk
            JPanel productPanel = new JPanel(new GridLayout(0, 3));
            productPanel.setBounds(4, 120, 500, 200); // Koordinat dan ukuran panel
            productPanel.setBackground(Color.WHITE);

            double totalProductPrice = 0.0;
            int totalProductQuantity = 0;

            // Menghitung jumlah produk untuk menentukan ukuran spasi yang sama
            int productCount = 0;
            while (productRs.next()) {
                productCount++;
            }
            productRs.beforeFirst(); // Mengembalikan cursor ke awal

            // Ukuran spasi antar produk
            int spaceSize = 10;
            int panelHeight = (productCount * spaceSize) + (productCount * 20);

            productPanel.setBounds(4, 120, 500, panelHeight); // Mengatur ukuran panel sesuai dengan jumlah produk

            JLabel product = new JLabel(" Product List :");
            JLabel blank1 = new JLabel("");
            JLabel blank2 = new JLabel("");
            productPanel.add(product);
            productPanel.add(blank1);
            productPanel.add(blank2);

            while (productRs.next()) {
                String productName = productRs.getString("product_name");
                double productPrice = productRs.getDouble("price");
                int productQuantity = productRs.getInt("quantity");

                JLabel nameLabel = new JLabel("  -   " +productName);
                JLabel priceLabel = new JLabel("$ " + Double.toString(productPrice));
                JLabel quantityLabel = new JLabel(Integer.toString(productQuantity)  + " pcs ");

                productPanel.add(nameLabel);
                productPanel.add(priceLabel);
                productPanel.add(quantityLabel);

                totalProductPrice += productPrice * productQuantity;
                totalProductQuantity += productQuantity;
            }

            mainPanel.add(productPanel);

            // Panel informasi penghematan
            JPanel savingPanel = new JPanel(new GridLayout(1, 1));
            savingPanel.setBounds(205, 310, 150, 50); // Koordinat dan ukuran panel
            savingPanel.setBackground(Color.WHITE);

            double savingAmount = totalProductPrice - discountedPrice;
            JLabel savingLabel = new JLabel("You Save : $ " + String.format("%.2f", savingAmount));
            savingPanel.add(savingLabel);

            mainPanel.add(savingPanel);

            // Tombol OK
            JButton okButton = new JButton("OK");
            okButton.setBounds(180, 360, 150, 30); // Koordinat dan ukuran tombol
            okButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    frame.dispose(); // Menutup frame saat tombol OK diklik
                }
            });

            mainPanel.add(okButton);

            frame.getContentPane().add(mainPanel);
            frame.setVisible(true);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error in retrieving bundle products: " + e.getMessage());
        }
    }

    public void addToCart(int index, JLabel[] nameLabels, JLabel[] hargaLabels) {        
        String productName = nameLabels[index].getText();
        double price = Double.parseDouble(hargaLabels[index].getText().replace("$ ", ""));

        addToCartDatabase(productName, null, price);
        JOptionPane.showMessageDialog(null, productName + " added to cart.");
    }
    
}
