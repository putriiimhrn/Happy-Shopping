package controller;

public class ItemMenuController {   
    public void sleep(){
        try{
            Thread.sleep(20);
        }catch(Exception e){
            
        }
    }
}
