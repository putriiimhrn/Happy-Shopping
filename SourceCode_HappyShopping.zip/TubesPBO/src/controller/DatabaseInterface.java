package controller;

import java.sql.ResultSet;


public interface DatabaseInterface {
    public ResultSet view(String SQLString);
    public void update(String SQLString);
}
