package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


public class Database implements DatabaseInterface{
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/happyShopping";
    private static final String USER = "root";
    private static final String PASS = "12345678";
    private static Connection conn;
    private static PreparedStatement stmt;
    private static ResultSet rs;
   
    public Database(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(JDBC_URL,USER,PASS);
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,""+e.getMessage(),
       "Connection Error",JOptionPane.WARNING_MESSAGE);
        }
    }
    
    public ResultSet view(String SQLString){
        try{
            stmt = conn.prepareStatement(SQLString,ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rs = stmt.executeQuery();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,
            "Error :"+e.getMessage(),"Communication Error", 
            JOptionPane.WARNING_MESSAGE);
        }
        return rs; 
    }
    public void update(String SQLString){
        try{
            stmt = conn.prepareStatement(SQLString);
            stmt.executeUpdate();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,
            "Error :"+e.getMessage(),"Communication Error",
            JOptionPane.WARNING_MESSAGE);
        }
    }
    
}
