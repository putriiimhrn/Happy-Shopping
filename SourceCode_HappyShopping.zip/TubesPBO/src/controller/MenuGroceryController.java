package controller;

import java.sql.ResultSet;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import model.Products;

public class MenuGroceryController extends MenuStationaryController{
    private Products products = new Products();
    private Database db = new Database();
    public void showMenuGrocery(JLabel[] nameLabels,  JLabel[] brandLabels,
                                JLabel[] hargaLabels, JLabel[] stockLabels){
        String psql = "SELECT product_name, brand, price, stock FROM products WHERE category = 'grocery' ORDER BY id;";

        try{
            
            ResultSet rs = db.view(psql);
            int i = 0;

            while (rs.next() && i < 15)
            {
                
                products.setProduct_name(rs.getString("product_name"));
                products.setBrand(rs.getString("brand"));
                products.setPrice(rs.getDouble("price"));
                products.setStock(rs.getInt("stock"));
            
                nameLabels[i].setText(products.getProduct_name());
                brandLabels[i].setText(products.getBrand());
                hargaLabels[i].setText("$ " + Double.toString(products.getPrice()));
                stockLabels[i].setText(Integer.toString(products.getStock()) + " pcs");

                i++;
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
}
