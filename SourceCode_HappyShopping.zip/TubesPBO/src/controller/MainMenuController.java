package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import model.customer;
import view.ItemMenu;
import view.LoginView;
import view.MenuDiscountView;
import view.MenuGroceryView;
import view.MenuStationeryView;

public class MainMenuController {
    private customer c = customer.getInstance();
    private Database db = new Database();
    
    public void execute(JPanel pn_temp, JPanel pn_menus, JLabel jLabel2, JFrame f) {
        jLabel2.setText("Hello "+ getNama());
        ImageIcon iconHome = new ImageIcon(getClass().getResource("/Icon/icon_menu_homepage.png"));
        ItemMenu menuHome = new ItemMenu(iconHome, false, null, "Homepage", new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                pn_temp.removeAll();
                pn_temp.repaint();
                pn_temp.revalidate();
            }
        });
        addMenu(pn_menus, menuHome);
                
        ImageIcon iconGrocery = new ImageIcon(getClass().getResource("/Icon/icon_submenu_grocery.png"));
        ItemMenu submenuGrocery = new ItemMenu(null, true, iconGrocery, "Grocery", new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                pn_temp.removeAll();
                pn_temp.add(new MenuGroceryView());
                pn_temp.repaint();
                pn_temp.revalidate();
            }
        });
                
        ImageIcon iconStationary = new ImageIcon(getClass().getResource("/Icon/icon_submenu_stationary.png"));
        ItemMenu submenuStationary = new ItemMenu(null, true, iconStationary, "Stationery", new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                pn_temp.removeAll();
                pn_temp.add(new MenuStationeryView());
                pn_temp.repaint();
                pn_temp.revalidate();
            }
        });
                
        ImageIcon iconDiscount = new ImageIcon(getClass().getResource("/Icon/icon_submenu_discount.png"));
        ItemMenu submenuDiscount = new ItemMenu(null, true, iconDiscount, "Discount ", new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                pn_temp.removeAll();
                pn_temp.add(new MenuDiscountView());
                pn_temp.repaint();
                pn_temp.revalidate();
            }
        });
        
        ImageIcon iconProduct = new ImageIcon(getClass().getResource("/Icon/icon_menu_product.png"));
        ItemMenu menuProduct = new ItemMenu(iconProduct, false, null, "Products", null, submenuGrocery, submenuStationary, submenuDiscount);
        addMenu(pn_menus, menuProduct);
        
        ItemMenu blank = new ItemMenu(null, true, null, null, null);
        addMenu(pn_menus, blank);
        
        ImageIcon iconLogout = new ImageIcon(getClass().getResource("/Icon/icon_menu_logout.png"));
        ItemMenu menuLogout = new ItemMenu(iconLogout, false, null, "Log Out", new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                f.setVisible(false);
                new LoginView().setVisible(true);
            }
        });
        addMenu(pn_menus, menuLogout );
    }
    
    private void addMenu(JPanel pn_menus, ItemMenu... menu){
        for (int i = 0; i < menu.length; i++){
            pn_menus.add(menu[i]);
            ArrayList<ItemMenu> subMenu = menu[i].getSubMenu();
            for (ItemMenu m : subMenu){
                addMenu(pn_menus,m);
            }
        }
        pn_menus.revalidate();
    }
    public String getNama(){
        String sql = "SELECT * FROM customer WHERE customer_id='"+c.getCustomer_id()+"';";
        ResultSet rs = db.view(sql);
       
        try {
            if (rs.next()){
                return rs.getString("customer_name");
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainMenuController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }
}
